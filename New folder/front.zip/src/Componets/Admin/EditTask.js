import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';
import './AddTask.css'; // Import the same CSS for styling

const EditTask = () => {
    const { id } = useParams();
    const [taskName, setTaskName] = useState('');
    const [description, setDescription] = useState('');
    const [assignedTo, setAssignedTo] = useState('');
    const [departmentId, setDepartmentId] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [status, setStatus] = useState('pending');
    const [users, setUsers] = useState([]);

    useEffect(() => {
        const fetchTaskData = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/api/tasks/${id}`);
                const taskData = response.data;
                setTaskName(taskData.title);
                setDescription(taskData.description);
                setAssignedTo(taskData.assignedTo);
                setDepartmentId(taskData.departmentId);
                setStartDate(taskData.startDate.split('T')[0]);
                setEndDate(taskData.endDate.split('T')[0]);
                setDueDate(taskData.dueDate.split('T')[0]);
                setStatus(taskData.status);
            } catch (error) {
                console.error("Error fetching task:", error);
            }
        };

        fetchTaskData();
    }, [id]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');

        const config = {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        };
        const taskData = {
            title: taskName,
            description,
            assignedTo,
            departmentId,
            startDate,
            endDate,
            dueDate,
            status,
        };

        try {
            await axios.patch(`http://localhost:5000/api/tasks/department/${id}`, taskData);
            toast.success('Task successfully updated!', {
                position: 'top-right',
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } catch (error) {
            console.error("Error updating task:", error);
            toast.error('Failed to update task. Please try again.', {
                position: 'top-right',
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    };

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/users');
                setUsers(response.data);
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        };
        fetchUsers();
    }, []);

    return (
        <div className="add-task-container">
            <ToastContainer />
            <form onSubmit={handleSubmit} className="add-task-form">
                <h2>Edit Task</h2>

                <input
                    type="text"
                    placeholder="Task Name"
                    value={taskName}
                    onChange={(e) => setTaskName(e.target.value)}
                />

                <input
                    placeholder="Task Description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                />

                <select
                    value={assignedTo}
                >
                    <option value="">Select User</option>
                    {users.map(user => (
                        <option key={user._id} value={user._id}>{user.name}</option>
                    ))}
                </select>

                <input
                    type="text"
                    placeholder="Department"
                    value={departmentId}
                    readOnly
                />

                <div className="date-input-container">
                    <label htmlFor="start-date">Start Date</label>
                    <input
                        id="start-date"
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                    />
                </div>

                <div className="date-input-container">
                    <label htmlFor="end-date">End Date</label>
                    <input
                        id="end-date"
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                    />
                </div>

                <div className="date-input-container">
                    <label htmlFor="due-date">Due Date</label>
                    <input
                        id="due-date"
                        type="date"
                        value={dueDate}
                        onChange={(e) => setDueDate(e.target.value)}
                    />
                </div>

                <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                >
                    <option value="pending">Pending</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed-Intime">completed-Intime</option>
                    <option value="completed-withDelay">completed-WithDelay</option>
                </select>

                <button type="submit">Update Compliance</button>
            </form>
        </div>
    );
};

export default EditTask;
