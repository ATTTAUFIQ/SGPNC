import React from 'react';
import { Link } from 'react-router-dom';
import './AdminPanel.css'; // Ensure you have a CSS file for styling

export default function SuperSideBar() {
  return (
    <div className="admin-panel">
            <ul className="admin-panel-list">
                <li><Link to="/superAdmin/">Add Dperment</Link></li>
                <li><Link to="/superAdmin/superTask">Display Compliance</Link></li>
                <li><Link to="/superAdmin/SuperDept">Display Deperments</Link></li>
                <li><Link to="/superAdmin/superUser">Display  Users</Link></li>
            </ul>
        </div>
  )
}


