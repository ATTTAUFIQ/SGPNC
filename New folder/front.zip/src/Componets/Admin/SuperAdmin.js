
import React from 'react'
import SuperSideBar from './SuperSideBar'

export default function SuperAdmin() {
  return (
    <div>
        <SuperSideBar/>
      <h1>Super Admin</h1>
    </div>
  )
}
