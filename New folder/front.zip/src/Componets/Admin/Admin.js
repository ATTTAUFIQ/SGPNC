import React from 'react';
import AdminPanel from './AdminPanel';

const Admin = () => {
    return (
        <div className="main-container">
            <div className="content">
                <AdminPanel />
            </div>
        </div>
    );
};

export default Admin;
