import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './SuperUsers.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function SuperUsers() {
    const [users, setUsers] = useState([]);
    const [departments, setDepartments] = useState({});

    // Fetch all users and departments on component mount
    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/users');
                setUsers(response.data);
            } catch (error) {
                console.error('Error fetching users:', error);
                toast.error('Error fetching users');
            }
        };

        const fetchDepartments = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/departments');
                const departmentMap = response.data.reduce((acc, department) => {
                    acc[department._id] = department.name;
                    return acc;
                }, {});
                setDepartments(departmentMap);
            } catch (error) {
                console.error('Error fetching departments:', error);
                toast.error('Error fetching departments');
            }
        };

        fetchUsers();
        fetchDepartments();
    }, []);

    // Handle making a user an admin
    const makeAdmin = async (userId) => {
        try {
            await axios.put(`http://localhost:5000/api/users/role/${userId}`, { role: 'admin' });
            // Update the role locally for better UX
            setUsers((prevUsers) =>
                prevUsers.map((user) =>
                    user._id === userId ? { ...user, role: 'admin' } : user
                )
            );
            toast.success('User role updated to Admin successfully!', {
                position: 'top-right',
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
        } catch (error) {
            toast.error('Failed to update user role. Please try again.', {
                position: 'top-right',
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
        }
    };

    return (
        <div className="users-container">
            <h2>Users</h2>
            <ToastContainer />
            <div className="users-grid">
                {users.length > 0 ? (
                    users.map((user) => (
                        <div className="user-card" key={user._id}>
                            <h3>{user.name}</h3>
                            <p><strong>Email:</strong> {user.email}</p>
                            <p><strong>Role:</strong> {user.role}</p>
                            <p><strong>Department:</strong> {departments[user.departmentId]}</p>
                            {/* Show button only if the user is not Admin or SuperAdmin */}
                            {user.role.toLowerCase() !== 'admin' &&
                                user.role.toLowerCase() !== 'superadmin' && (
                                    <button
                                        className="make-admin-btn"
                                        onClick={() => makeAdmin(user._id)}
                                    >
                                        Make Admin
                                    </button>
                                )}
                        </div>
                    ))
                ) : (
                    <p>No users available.</p>
                )}
            </div>
        </div>
    );
}
