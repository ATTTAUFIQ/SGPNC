import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './DisplayComponent.css'; // Use the same CSS for styling
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';

const CompletedTask = () => {
    const [tasks, setTasks] = useState([]);
    const [users, setUsers] = useState({});
    const [departments, setDepartments] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        const fetchTasks = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/tasks/department');
                setTasks(response.data.filter(task => task.status === "completed" ||  task.status === "completed-Intime" || task.status === "completed-Withdelay"));
            } catch (error) {
                console.error("Error fetching tasks:", error);
            }
        };

        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/users');
                const userMap = response.data.reduce((acc, user) => {
                    acc[user._id] = user.name;
                    return acc;
                }, {});
                setUsers(userMap);
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        };

        const fetchDepartments = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/departments');
                const departmentMap = response.data.reduce((acc, department) => {
                    acc[department._id] = department.name;
                    return acc;
                }, {});
                setDepartments(departmentMap);
            } catch (error) {
                console.error("Error fetching departments:", error);
            }
        };

        fetchTasks();
        fetchUsers();
        fetchDepartments();
    }, []);

    const handleUpdate = async (taskId) => {
        navigate(`/admin/edit-task/${taskId}`);
    };

    const handleDelete = async (taskId) => {
        try {
            await axios.delete(`http://localhost:5000/api/tasks/department/${taskId}`);
            setTasks(tasks.filter(task => task._id !== taskId));
            toast.success('Task deleted successfully!');
        } catch (error) {
            console.error("Error deleting task:", error);
            toast.error('Failed to delete task.');
        }
    };

    return (
        <div className="task-display">
            <ToastContainer />
            <h2>Completed Compliance</h2>
            {tasks.length > 0 ? (
                <div className="task-grid">
                    {tasks.map((task) => (
                        <div className="task-card" key={task._id}>
                            <h3>{task.title}</h3>
                            <p><strong>Description:</strong> {task.description}</p>
                            <p><strong>Assigned To:</strong> {users[task.assignedTo] || "Unknown"}</p>
                            <p><strong>Department:</strong> {departments[task.departmentId] || "Unknown"}</p>
                            <p><strong>Assigned By:</strong> {users[task.assignedBy] || "Unknown"}</p>
                            <p><strong>Start Date:</strong> {new Date(task.startDate).toLocaleDateString('en-GB', {
                                day: '2-digit', month: '2-digit', year: 'numeric'
                            })}</p>
                            <p><strong>End Date:</strong> {new Date(task.endDate).toLocaleDateString('en-GB', {
                                day: '2-digit', month: '2-digit', year: 'numeric'
                            })}</p>
                            <p><strong>Due Date:</strong> {new Date(task.dueDate).toLocaleDateString('en-GB', {
                                day: '2-digit', month: '2-digit', year: 'numeric'
                            })}</p>
                            <p><strong>Status:</strong> {task.status}</p>
                            <div className="task-actions">
                                <button onClick={() => handleUpdate(task._id)}>Update</button>
                                <button onClick={() => handleDelete(task._id)}>Delete</button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <p>No completed compliance available.</p>
            )}
        </div>
    );
};

export default CompletedTask;
