import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './SuperDeperment.css'

export default function SuperDepartment() {
    const [departments, setDepartments] = useState([]);

    // Fetch all departments on component mount
    useEffect(() => {
        const fetchDepartments = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/departments');
                setDepartments(response.data);
            } catch (error) {
                console.error('Error fetching departments:', error);
            }
        };
        fetchDepartments();
    }, []);

    return (
        <div className="department-container">
            <h2>Departments</h2>
            <div className="department-grid">
                {departments.length > 0 ? (
                    departments.map((department) => (
                        <div className="department-card" key={department._id}>
                            <h3>{department.name}</h3>
                        </div>
                    ))
                ) : (
                    <p>No departments available.</p>
                )}
            </div>
        </div>
    );
}
