import React from 'react';
import { Link } from 'react-router-dom';
import './AdminPanel.css'; // Ensure you have a CSS file for styling

const AdminPanel = () => {
    return (
        <div className="admin-panel">
            <ul className="admin-panel-list">
                <li><Link to="/admin/">Add Compliance</Link></li>
                <li><Link to="/admin/display-task">Display Compliance</Link></li>
                <li><Link to="/admin/completed-task">Completed Compliance</Link></li>
                <li><Link to="/admin/delayed-task">Delayed Compliance</Link></li>
            </ul>
        </div>
    );
};

export default AdminPanel;
