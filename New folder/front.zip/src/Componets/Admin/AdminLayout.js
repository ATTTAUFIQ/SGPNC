import React from 'react';
import { Outlet } from 'react-router-dom';
import AdminPanel from './AdminPanel';

const AdminLayout = () => {
    return (
        <div className="admin-layout">
            <AdminPanel />
            <div className="admin-content">
                <Outlet /> {/* This is where nested routes will render their components */}
            </div>
        </div>
    );
};

export default AdminLayout;
