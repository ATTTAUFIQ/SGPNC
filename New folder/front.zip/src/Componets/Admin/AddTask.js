import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AddTask.css'; // Make sure to import your CSS file
import { useAuth } from '../Context/auth';
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';

const AddTask = ({ onAddTask }) => {
    const [taskName, setTaskName] = useState('');
    const [description, setDescription] = useState('');
    const [assignedTo, setAssignedTo] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [status, setStatus] = useState("pending");
    const [users, setUsers] = useState([]);
    const data = useAuth();

    const fetchUsers = async () => {
        if (data.auth && data.auth.departmentId) {
            try {
                const response = await axios.get('http://localhost:5000/api/users');
                const filteredUsers = response.data.filter(
                    user => user.departmentId === data.auth.departmentId && user.role === 'employee'
                );
                setUsers(filteredUsers);
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            await axios.post('http://localhost:5000/api/tasks', {
                title: taskName,
                description,
                assignedTo,
                departmentId: data.auth.departmentId,
                assignedBy: data.auth.user,
                startDate,
                endDate,
                dueDate,
                status
            });

            toast.success('Task successfully added!', {
                position: 'top-right',
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });

            onAddTask({
                title: taskName,
                description,
                assignedTo,
                departmentId: data.auth.departmentId,
                assignedBy: data.auth.user,
                startDate,
                endDate,
                dueDate,
                status
            });

            // Reset form fields
            setTaskName('');
            setDescription('');
            setAssignedTo('');
            setStartDate('');
            setEndDate('');
            setDueDate('');
            setStatus('pending');

        } catch (error) {
            console.error("Error adding task:", error);
            toast.error('Failed to add task. Please try again.', {
                position: 'top-right',
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    return (
        <div className="add-task-container">
            <ToastContainer />
            <form onSubmit={handleSubmit} className="add-task-form">
                <h2>Add Compliance</h2>

                <input
                    type="text"
                    placeholder="Compliance Name"
                    value={taskName}
                    onChange={(e) => setTaskName(e.target.value)}
                />

                <input
                    placeholder="Compliance Description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                />

                <select
                    value={assignedTo}
                    onChange={(e) => setAssignedTo(e.target.value)}
                    onClick={fetchUsers}
                >
                    <option value="">Select User</option>
                    {users.map(user => (
                        <option key={user._id} value={user._id}>{user.name}</option>
                    ))}
                </select>

                <div className="date-input-container">
                    <label htmlFor="start-date">Start Date</label>
                    <input
                        id="start-date"
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                    />
                </div>

                <div className="date-input-container">
                    <label htmlFor="end-date">End Date</label>
                    <input
                        id="end-date"
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                    />
                </div>

                <div className="date-input-container">
                    <label htmlFor="due-date">Due Date</label>
                    <input
                        id="due-date"
                        type="date"
                        value={dueDate}
                        onChange={(e) => setDueDate(e.target.value)}
                    />
                </div>

                <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                >
                    <option value="pending">Pending</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed-Intime">completed-Intime</option>
                    <option value="completed-withDelay">completed-WithDelay</option>
                </select>

                <button type="submit">Add Compliance</button>
            </form>
        </div>
    );
};

export default AddTask;
