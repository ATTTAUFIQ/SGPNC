import React from 'react';
import { Outlet } from 'react-router-dom';
import SuperSideBar from './SuperSideBar';

export default function SuperAdminLayout() {
  return (
    <div>
      <div className="admin-layout">
            <SuperSideBar />
            <div className="admin-content">
                <Outlet /> {/* This is where nested routes will render their components */}
            </div>
        </div>
    </div>
  )
}

