import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './DisplayComponent.css';
import { ToastContainer } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';

export default function SuperTask() {
    const [tasks, setTasks] = useState([]);
    const [users, setUsers] = useState({});
    const [departments, setDepartments] = useState({});

    useEffect(() => {
        const fetchTasks = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/tasks/all');
                setTasks(response.data);
            } catch (error) {
                console.error("Error fetching tasks:", error);
            }
        };

        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/users');
                const userMap = response.data.reduce((acc, user) => {
                    acc[user._id] = user.name;
                    return acc;
                }, {});
                setUsers(userMap);
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        };

        const fetchDepartments = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/departments');
                const departmentMap = response.data.reduce((acc, department) => {
                    acc[department._id] = department.name;
                    return acc;
                }, {});
                setDepartments(departmentMap);
            } catch (error) {
                console.error("Error fetching departments:", error);
            }
        };

        fetchTasks();
        fetchUsers();
        fetchDepartments();
    }, []);

    // Group tasks by department
    const groupedTasks = tasks.reduce((acc, task) => {
        const departmentId = task.departmentId;
        if (!acc[departmentId]) {
            acc[departmentId] = [];
        }
        acc[departmentId].push(task);
        return acc;
    }, {});

    return (
        <div className="task-display">
            <ToastContainer />
            <h2>All Compliance</h2>
            {Object.keys(groupedTasks).length > 0 ? (
                Object.keys(groupedTasks).map((departmentId) => (
                    <div key={departmentId}>
                        <h3>Department :- {departments[departmentId] || "Unknown Department"}</h3>
                        <div className="task-grid">
                            {groupedTasks[departmentId].map((task) => (
                                <div className="task-card" key={task._id}>
                                    <h3>{task.title}</h3>
                                    <p><strong>Description:</strong> {task.description}</p>
                                    <p><strong>Assigned To:</strong> {users[task.assignedTo] || "Unknown"}</p>
                                    <p><strong>Assigned By:</strong> {users[task.assignedBy] || "Unknown"}</p>
                                    <p><strong>Start Date:</strong> {new Date(task.startDate).toLocaleDateString('en-GB')}</p>
                                    <p><strong>End Date:</strong> {new Date(task.endDate).toLocaleDateString('en-GB')}</p>
                                    <p><strong>Due Date:</strong> {new Date(task.dueDate).toLocaleDateString('en-GB')}</p>
                                    <p><strong>Status:</strong> {task.status|| "pending"}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                ))
            ) : (
                <p>No Compliance available.</p>
            )}
        </div>
    );
}