import React, { useState } from 'react';
import axios from 'axios';
import './SuperCreateDperment.css'
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';

export default function SuperCreateDepartment() {
    const [departmentName, setDepartmentName] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!departmentName.trim()) {
            toast.error('Department name cannot be empty');
            return;
        }

        try {
            const response = await axios.post('http://localhost:5000/api/departments', { name: departmentName });
            toast.success('Task successfully added', {
                position: 'top-right',
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
            setDepartmentName(''); // Clear the input field after successful submission
        } catch (error) {
            console.error('Error creating department:', error);
            toast.error('Failed to add task', {
                position: 'top-right',
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    };

    return (
        <div className="create-department-form">
            <ToastContainer />
            <h2>Create New Department</h2>
            <form onSubmit={handleSubmit}>
                <label htmlFor="departmentName">Department Name:</label>
                <input
                    type="text"
                    id="departmentName"
                    value={departmentName}
                    onChange={(e) => setDepartmentName(e.target.value)}
                    placeholder="Enter department name"
                />
                <button type="submit">Create Department</button>
            </form>
        </div>
    );
}
