import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Events.css"; // Make sure to import your CSS file
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';

export default function Events() {
    const [tasks, setTasks] = useState([]);
    const [users, setUsers] = useState({});
    const [departments, setDepartments] = useState({});
    const navigate = useNavigate();

    const fetchTasks = async () => {
        try {
            const response = await axios.get("http://localhost:5000/api/tasks");
            setTasks(response.data);
        } catch (error) {
            console.error("Error fetching tasks:", error);
        }
    };

    useEffect(() => {
        const fetchTasks = async () => {
            try {
                const response = await axios.get("http://localhost:5000/api/tasks");
                setTasks(response.data);
            } catch (error) {
                console.error("Error fetching tasks:", error);
            }
        };

        const fetchUsers = async () => {
            try {
                const response = await axios.get("http://localhost:5000/api/users");
                const userMap = response.data.reduce((acc, user) => {
                    acc[user._id] = user.name;
                    return acc;
                }, {});
                setUsers(userMap);
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        };

        const fetchDepartments = async () => {
            try {
                const response = await axios.get("http://localhost:5000/api/departments");
                const token = localStorage.getItem("token");

                const config = {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                };
                const departmentMap = response.data.reduce((acc, department) => {
                    acc[department._id] = department.name;
                    return acc;
                }, {});
                setDepartments(departmentMap);
            } catch (error) {
                console.error("Error fetching departments:", error);
            }
        };

        fetchTasks();
        fetchUsers();
        fetchDepartments();
    }, []);

    const handleUpdate = async (taskId, dueDate) => {
        try {
            const currentDate = new Date();
            const taskDueDate = new Date(dueDate);
    
            // Determine the status based on the completion time
            const newStatus = currentDate <= taskDueDate ? "completed-Intime" : "completed-Withdelay";
    
            // Update the task's status
            await axios.patch(`http://localhost:5000/api/tasks/${taskId}`, { status: newStatus });
    
            // Show a success toast message
            toast.success(`Task marked as ${newStatus}!`, {
                position: 'top-right',
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
    
            // Refresh tasks
            fetchTasks();
        } catch (error) {
            console.error("Error updating task:", error);
            toast.error('Failed to update task status.');
        }
    };
    

    return (
        <div className="task-displa">
            <ToastContainer />
            <h2>All Compliance</h2>
            {tasks.length > 0 ? (
                <div className="task-grid">
                    {tasks.map((task) => (
                        <div className="task-card" key={task._id}>
                            <h3>{task.title}</h3>
                            <p><strong>Description:</strong> {task.description}</p>
                            <p><strong>Assigned To:</strong> {users[task.assignedTo] || "Unknown"}</p>
                            <p><strong>Department:</strong> {departments[task.departmentId] || "Unknown"}</p>
                            <p><strong>Assigned By:</strong> {users[task.assignedBy] || "Unknown"}</p>
                            <p><strong>Start Date:</strong> {new Date(task.startDate).toLocaleDateString('en-GB')}</p>
                            <p><strong>End Date:</strong> {new Date(task.endDate).toLocaleDateString('en-GB')}</p>
                            <p><strong>Due Date:</strong> {new Date(task.dueDate).toLocaleDateString('en-GB')}</p>
                            <p><strong>Status:</strong> {task.status}</p>
                            <div className="task-actions">
                                <button onClick={() => handleUpdate(task._id, task.dueDate)}>Mark as Completed</button>
                            </div>

                        </div>
                    ))}
                </div>
            ) : (
                <p>No compliance available.</p>
            )}
        </div>
    );
}
