import React, { useState } from 'react';
import { Button, TextField, Checkbox, FormControlLabel, Typography, Box, Link, Grid } from '@mui/material';
import { FaFacebookF, FaTwitter, FaGithub } from 'react-icons/fa';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';

const theme = createTheme({
  typography: {
    fontFamily: 'Poppins, Roboto, sans-serif',
    body1: { fontSize: '1rem' },
    body2: { fontSize: '0.9rem' },
    h4: { fontSize: '2rem', fontWeight: 600 },
  },
});

const Forgot = () => {
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [DOB, setDOB] = useState('');

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Attempt to register the user
      const response = await axios.post("http://localhost:5000/api/users//update-password", {email,DOB,password});
      
      // If registration is successful, show success toast
      toast.success('Password updated!', {
        position: 'top-right',
        autoClose: 2000, // Auto close after 3 seconds
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
  
      setTimeout(() => navigate('/'), 2500);

    } catch (error) {
      // Handle error case
      toast.error('failed. Please try again.', {
        position: 'top-right',
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
};
  



  return (
    <ThemeProvider theme={theme}>
       <ToastContainer /> {/* Toast container for displaying notifications */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100vw',
          height: '100vh',
          backgroundColor: '#f4f6f8',
          overflow: 'hidden',
        }}
      >
        <Grid
          container
          sx={{
            boxShadow: 3,
            borderRadius: 2,
            maxWidth: '100%',
            maxHeight: '100%',
            width: '100%',
            height: '100%',
            backgroundColor: 'white',
          }}
        >
          <Grid
            item
            xs={12}
            md={6}
            lg={8}
            sx={{
              display: { xs: 'none', md: 'flex' },
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: '#f8f9fa',
              height: '100%',
            }}
          >
            <Box
              component="img"
              src={'WhatsApp Image 2024-10-28 at 21.28.36_ef585de2.jpg'}
              alt="Illustration"
              sx={{
                width: '90%',
                height: '90%',
                objectFit: 'contain',
                objectPosition: 'center',
              }}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={6}
            lg={4}
            sx={{
              p: { xs: 3, md: 4 },
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100%',
              width: '100%',
            }}
          >
            <Typography component="h1" variant="h4" align="center" sx={{ fontWeight: 400, mb: 1, color: '#414a4c' }}>
              Welcome Sgp-n-c! 👋
            </Typography>
            <Typography variant="body2" color="textSecondary" align="center" sx={{ mb: 3 }}>
              Forgot account password 
            </Typography>
            {error && <Typography color="error" variant="body2" sx={{ mb: 2 }}>{error}</Typography>}
            <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1, width: { xs: '90%', md: '80%' } }}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="email"
                label="Email"
                placeholder="Enter Email"
                name="email"
                autoComplete="email"
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                sx={{ fontSize: { xs: '0.875rem', md: '1rem' }, fontWeight: 500, height: '48px' }}
              />

            <TextField
                margin="normal"
                required
                fullWidth
                name="DOB"
                label="Enter your birth date"
                type="date"
                value={DOB}
                onChange={(e) => setDOB(e.target.value)}
                InputLabelProps={{
                  shrink: true, // Ensures the label doesn't overlap the input
                }}
                sx={{
                  "& .MuiInputBase-root": {
                    height: "48px", // Consistent input height
                  },
                  "& input": {
                    padding: "10px", // Better spacing
                  },
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  fontWeight: 500,
                }}
              />

              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="New Password"
                type="password"
                id="password"
                placeholder='*******'
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                sx={{ fontSize: { xs: '0.875rem', md: '1rem' }, fontWeight: 500, height: '48px' }}
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                sx={{
                  mt: 3,
                  mb: 2,
                  backgroundColor: '#7367f0',
                  fontWeight: 600,
                  fontSize: { xs: '0.875rem', md: '1rem' },
                  ':hover': { backgroundColor: '#5a56c2' },
                }}
              >
                Forgot
              </Button>
              <Typography
                variant="body2"
                color="textSecondary"
                align="center"
                sx={{
                  mb: 2,
                  fontSize: '0.9rem',
                  fontWeight: 400,
                  '& a': { textDecoration: 'none', color: '#7367f0', fontWeight: 500, ':hover': { textDecoration: 'underline' } },
                }}
              >
                Try to login again!{' '}
                <Link href="/" variant="body2">
                  Login
                </Link>
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </ThemeProvider>
  );
};

export default Forgot;
