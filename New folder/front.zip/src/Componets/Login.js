import React, { useState } from 'react';
import { Button, TextField, Checkbox, FormControlLabel, Typography, Box, Link, Grid } from '@mui/material';
import { FaFacebookF, FaTwitter, FaGithub } from 'react-icons/fa';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css';
import { useAuth } from './Context/auth';

const theme = createTheme({
  typography: {
    fontFamily: 'Poppins, Roboto, sans-serif',
    body1: { fontSize: '1rem' },
    body2: { fontSize: '0.9rem' },
    h4: { fontSize: '2rem', fontWeight: 600 },
  },
});

const LoginPage = () => {
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth(); // Get login function from AuthContext

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Attempt to register the user
      const response = await axios.post("http://localhost:5000/api/users/login", {email,password});
      
      // If registration is successful, show success toast

  

      if (response.status === 201) {
        
        const { name, token,role ,departmentId} = response.data;


        // Use login function from AuthContext to save user data and token
        login(name, token, role, departmentId);

        
        toast.success('Login successful!', {
          position: 'top-right',
          autoClose: 2000, // Auto close after 3 seconds
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        
        // Navigate to login page after toast displays
        setTimeout(() => navigate('/main'), 2000);
      }
    } catch (error) {
      // Handle error case
      toast.error('Login failed. Please try again.', {
        position: 'top-right',
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
};
  

  const handleSocialLogin = (platform) => {
    alert(`Login with ${platform} is currently not implemented.`);
  };

  return (
    <ThemeProvider theme={theme}>
       <ToastContainer /> {/* Toast container for displaying notifications */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          width: '100vw',
          height: '100vh',
          backgroundColor: '#f4f6f8',
          overflow: 'hidden',
        }}
      >
        <Grid
          container
          sx={{
            boxShadow: 3,
            borderRadius: 2,
            maxWidth: '100%',
            maxHeight: '100%',
            width: '100%',
            height: '100%',
            backgroundColor: 'white',
          }}
        >
          <Grid
            item
            xs={12}
            md={6}
            lg={8}
            sx={{
              display: { xs: 'none', md: 'flex' },
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: '#f8f9fa',
              height: '100%',
            }}
          >
            <Box
              component="img"
              src={'SGPNC_Logo_FINAL_page-0001.jpg'}
              alt="Illustration"
              sx={{
                width: '90%',
                height: '90%',
                objectFit: 'contain',
                objectPosition: 'center',
              }}
            />
          </Grid>
          <Grid
            item
            xs={12}
            md={6}
            lg={4}
            sx={{
              p: { xs: 3, md: 4 },
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100%',
              width: '100%',
            }}
          >
            <Typography component="h1" variant="h4" align="center" sx={{ fontWeight: 800, mb: 1, color: '#414a4c' }}>
              Welcome 
            </Typography>
            <Typography variant="body2" color="textSecondary" align="center" sx={{ mb: 3 }}>
              Please login to acess your account
            </Typography>
            {error && <Typography color="error" variant="body2" sx={{ mb: 2 }}>{error}</Typography>}
            <Box component="form" onSubmit={handleSubmit} sx={{ mt: 1, width: { xs: '90%', md: '80%' } }}>
              <TextField
                margin="normal"
                required
                fullWidth
                id="email"
                label="Email or Username"
                placeholder="Enter Email or Username"
                name="email"
                autoComplete="email"
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                sx={{ fontSize: { xs: '0.875rem', md: '1rem' }, fontWeight: 500, height: '48px' }}
              />
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
                placeholder='*******'
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                sx={{ fontSize: { xs: '0.875rem', md: '1rem' }, fontWeight: 500, height: '48px' }}
              />
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      value="remember"
                      color="primary"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                    />
                  }
                  label="Remember me"
                  sx={{ fontWeight: 400 }}
                />
                <Link href="/forget" variant="body2" sx={{ fontSize: '0.9rem', fontWeight: 400, textDecoration: 'none' }}>
                  Forgot password?
                </Link>
              </Box>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                sx={{
                  mt: 3,
                  mb: 2,
                  backgroundColor: '#7367f0',
                  fontWeight: 600,
                  fontSize: { xs: '0.875rem', md: '1rem' },
                  ':hover': { backgroundColor: '#5a56c2' },
                }}
              >
                Login
              </Button>
              <Typography
                variant="body2"
                color="textSecondary"
                align="center"
                sx={{
                  mb: 2,
                  fontSize: '0.9rem',
                  fontWeight: 400,
                  '& a': { textDecoration: 'none', color: '#7367f0', fontWeight: 500, ':hover': { textDecoration: 'underline' } },
                }}
              >
                New on our platform?{' '}
                <Link href="/register" variant="body2">
                  Create an account
                </Link>
              </Typography>
              <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
                <Button onClick={() => handleSocialLogin('Facebook')} variant="outlined" color="primary" sx={{ mx: 1, fontSize: '1rem', minWidth: '40px', height: '40px' }}>
                  <FaFacebookF />
                </Button>
                <Button onClick={() => handleSocialLogin('Twitter')} variant="outlined" color="primary" sx={{ mx: 1, fontSize: '1rem', minWidth: '40px', height: '40px' }}>
                  <FaTwitter />
                </Button>
                <Button onClick={() => handleSocialLogin('GitHub')} variant="outlined" color="primary" sx={{ mx: 1, fontSize: '1rem', minWidth: '40px', height: '40px' }}>
                  <FaGithub />
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </ThemeProvider>
  );
};

export default LoginPage;
