import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Calendar.css';

const generateDaysForMonth = (month, year) => {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const daysArray = [];

    // Adding nulls for days before the first day of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
        daysArray.push(null);
    }

    // Adding actual day numbers
    for (let day = 1; day <= daysInMonth; day++) {
        daysArray.push(day);
    }

    return daysArray;
};

const Calendar = () => {
    const [tasks, setTasks] = useState([]);
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());

    useEffect(() => {
        const fetchTasks = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/tasks');
                setTasks(response.data);
            } catch (error) {
                console.error('Error fetching tasks:', error);
            }
        };

        fetchTasks();
    }, []);

    const months = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    const handleMonthChange = (direction) => {
        if (direction === 'prev') {
            if (currentMonth === 0) {
                setCurrentMonth(11);
                setCurrentYear(currentYear - 1);
            } else {
                setCurrentMonth(currentMonth - 1);
            }
        } else if (direction === 'next') {
            if (currentMonth === 11) {
                setCurrentMonth(0);
                setCurrentYear(currentYear + 1);
            } else {
                setCurrentMonth(currentMonth + 1);
            }
        }
    };

    const getTasksForDate = (day) => {
        if (day === null) {
            return [];
        }

        const dateStr = `${currentYear}-${(currentMonth + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
        return tasks.filter(task => {
            const taskStartDate = new Date(task.startDate);
            const taskEndDate = new Date(task.endDate);
            const currentDate = new Date(dateStr);

            return currentDate >= taskStartDate && currentDate <= taskEndDate;
        });
    };

    return (
        <div className="calendar">
            <div className="calendar-navigation">
                <button onClick={() => handleMonthChange('prev')}>&lt;</button>
                <h2>{months[currentMonth]} {currentYear}</h2>
                <button onClick={() => handleMonthChange('next')}>&gt;</button>
            </div>
            <div className="calendar-grid">
                <div className="calendar-day-header">Sun</div>
                <div className="calendar-day-header">Mon</div>
                <div className="calendar-day-header">Tue</div>
                <div className="calendar-day-header">Wed</div>
                <div className="calendar-day-header">Thu</div>
                <div className="calendar-day-header">Fri</div>
                <div className="calendar-day-header">Sat</div>

                {generateDaysForMonth(currentMonth, currentYear).map((day, index) => {
                    const taskForDate = getTasksForDate(day);
                    const isStartDate = taskForDate.some(task =>
                        new Date(task.startDate).getDate() === day && new Date(task.startDate).getMonth() === currentMonth && new Date(task.startDate).getFullYear() === currentYear
                    );
                    const isEndDate = taskForDate.some(task =>
                        new Date(task.endDate).getDate() === day && new Date(task.endDate).getMonth() === currentMonth && new Date(task.endDate).getFullYear() === currentYear
                    );

                    return (
                        <div key={index} className={`calendar-day ${day === null ? 'null' : ''} ${taskForDate.length > 0 ? 'has-event' : ''} ${isStartDate ? 'start-date' : ''} ${isEndDate ? 'end-date' : ''}`}>
                            {day}
                            {day && taskForDate.map((task, taskIndex) => (
                                <div key={taskIndex} className="calendar-task">
                                    <div className="calendar-task-content">
                                        <div className="calendar-task-name">{task.title}</div>
                                        <div className="calendar-task-status">Status: {task.status}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default Calendar;
