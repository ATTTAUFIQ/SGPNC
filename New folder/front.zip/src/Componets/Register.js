import React, { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Checkbox,
  FormControlLabel,
  Typography,
  Box,
  Link,
  Grid,
  MenuItem,
} from "@mui/material";
import { FaFacebookF, FaTwitter, FaGithub } from "react-icons/fa";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const theme = createTheme({
  typography: {
    fontFamily: "Poppins, Roboto, sans-serif",
    body1: { fontSize: "1rem" },
    body2: { fontSize: "0.9rem" },
    h4: { fontSize: "2rem", fontWeight: 600 },
  },
});

const LoginPage = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "",
    departmentId: "",
    DOB: "",
  });
  const [departments, setDepartments] = useState([]);

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleClick = async (e) => {
    e.preventDefault();

    // Set departmentId to null if the role is superAdmin
    if (formData.role === "superAdmin") {
      setFormData((prevData) => ({
        ...prevData,
        departmentId: null,
      }));
    }

    // Validate that departmentId is required only if role is not superAdmin
    if (formData.role !== "superAdmin" && !formData.departmentId) {
      toast.error("Department is required for this role.", {
        position: "top-right",
        autoClose: 3000,
      });
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/users/register",
        formData
      );
      if (response.status === 201) {
        toast.success("Register successful!", {
          position: "top-right",
          autoClose: 3000,
        });
        setTimeout(() => navigate("/"), 3000);
      }
    } catch (error) {
      toast.error("Register failed. Please try again.", {
        position: "top-right",
        autoClose: 3000,
      });
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("token");

    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };

    const fetchDepartments = async () => {
      try {
        const response = await axios.get(
          "http://localhost:5000/api/departments",
          config
        );
        setDepartments(response.data);
      } catch (error) {
        console.error("Error fetching departments:", error);
      }
    };

    fetchDepartments();
  }, []);

  return (
    <ThemeProvider theme={theme}>
      <ToastContainer />
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "100vw",
          height: "100vh",
          backgroundColor: "#f4f6f8",
          overflow: "hidden",
        }}
      >
        <Grid
          container
          sx={{
            boxShadow: 3,
            borderRadius: 2,
            maxWidth: "100%",
            width: "100%",
            height: "100%",
            backgroundColor: "white",
          }}
        >
          <Grid
            item
            xs={12}
            md={6}
            lg={8}
            sx={{
              display: { xs: "none", md: "flex" },
              justifyContent: "center",
              alignItems: "center",
              backgroundColor: "#f8f9fa",
              height: "100%",
            }}
          >
            <Box
              component="img"
              src={'SGPNC_Logo_FINAL_page-0001.jpg'}
              alt="Illustration"
              sx={{ width: "90%", height: "90%", objectFit: "contain" }}
            />
          </Grid>

          <Grid
            item
            xs={12}
            md={6}
            lg={4}
            sx={{
              p: { xs: 3, md: 4 },
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              height: "100%",
            }}
          >
            <Typography
              component="h1"
              variant="h4"
              align="center"
              sx={{ fontWeight: 800, mb: 1, color: "#414a4c" }}
            >
              Sign Up
            </Typography>

            <Box
              component="form"
              sx={{ mt: 1, width: { xs: "90%", md: "80%" } }}
            >
              <TextField
                margin="normal"
                required
                fullWidth
                name="name"
                label="Name"
                placeholder="Enter your name"
                value={formData.name}
                onChange={handleChange}
                sx={{
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  fontWeight: 500,
                  height: "48px",
                }}
              />
              <TextField
                margin="normal"
                required
                fullWidth
                name="email"
                label="Email or Username"
                placeholder="Enter Email or Username"
                value={formData.email}
                onChange={handleChange}
                sx={{
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  fontWeight: 500,
                  height: "48px",
                }}
              />
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                placeholder="*******"
                value={formData.password}
                onChange={handleChange}
                sx={{
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  fontWeight: 500,
                  height: "48px",
                }}
              />
              <TextField
                margin="normal"
                required
                fullWidth
                name="DOB"
                label="Enter your birth date"
                type="date"
                value={formData.DOB}
                onChange={handleChange}
                InputLabelProps={{
                  shrink: true, // Ensures the label doesn't overlap the input
                }}
                sx={{
                  "& .MuiInputBase-root": {
                    height: "48px", // Consistent input height
                  },
                  "& input": {
                    padding: "10px", // Better spacing
                  },
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  fontWeight: 500,
                }}
              />

              <TextField
                margin="normal"
                required
                fullWidth
                select
                name="role"
                label="Role"
                value={formData.role}
                onChange={handleChange}
                sx={{
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  fontWeight: 500,
                }}
              >
                {["employee"].map((option) => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </TextField>

              {/* Department Dropdown */}
              <TextField
                margin="normal"
                required={formData.role !== "superAdmin"} // Conditionally required
                fullWidth
                select
                name="departmentId"
                label="Department"
                value={formData.departmentId}
                onChange={handleChange}
                sx={{
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  fontWeight: 500,
                }}
                error={formData.role !== "superAdmin" && !formData.departmentId} // Show error if needed
                helperText={
                  formData.role !== "superAdmin" && !formData.departmentId
                    ? "Department is required"
                    : ""
                }
              >
                {departments.map((department) => (
                  <MenuItem key={department._id} value={department._id}>
                    {department.name}
                  </MenuItem>
                ))}
              </TextField>

              <FormControlLabel
                control={<Checkbox value="remember" color="primary" />}
                label="I agree to privacy policy & terms"
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                sx={{
                  mt: 3,
                  mb: 2,
                  backgroundColor: "#7367f0",
                  fontWeight: 600,
                  fontSize: { xs: "0.875rem", md: "1rem" },
                  ":hover": { backgroundColor: "#5a56c2" },
                }}
                onClick={handleClick}
              >
                Sign Up
              </Button>
              <Typography
                variant="body2"
                color="textSecondary"
                align="center"
                sx={{ mb: 2, fontSize: "0.9rem", fontWeight: 400 }}
              >
                Already have an account?{" "}
                <Link href="/" variant="body2">
                  Sign in instead
                </Link>
              </Typography>
              <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
                {[<FaFacebookF />, <FaTwitter />, <FaGithub />].map(
                  (icon, index) => (
                    <Button
                      key={index}
                      variant="outlined"
                      color="primary"
                      sx={{
                        mx: 1,
                        fontSize: "1rem",
                        minWidth: "40px",
                        height: "40px",
                      }}
                    >
                      {icon}
                    </Button>
                  )
                )}
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </ThemeProvider>
  );
};

export default LoginPage;
