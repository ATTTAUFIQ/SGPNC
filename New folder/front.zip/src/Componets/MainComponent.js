import React from 'react';
import Calendar from './Calendar';
import OverdueEvents from './OverdueEvents';

const MainComponent = ({ tasks }) => {
    return (
        <div className="main-container">
            <div className="content">
                <Calendar tasks={tasks} />
                <OverdueEvents />
            </div>
        </div>
    );
};

export default MainComponent;
