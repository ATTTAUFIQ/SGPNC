import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './OverdueEvents.css';

const OverdueEvents = () => {
    const [tasks, setTasks] = useState([]);
    const [timelyTasks, setTimelyTasks] = useState([]);
    const [lateTasks, setLateTasks] = useState([]);
    const [pendingTasks, setPendingTasks] = useState([]); // New state for pending tasks

    useEffect(() => {
        const fetchTasks = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/tasks'); // Replace with your API URL
                const allTasks = response.data;
                const today = new Date();

                // Separate timely, late, and pending tasks
                const timely = allTasks.filter(task => 
                    task.status === 'completed-Intime' 
                );
                const late = allTasks.filter(task => 
                    task.status === 'completed-withDelay'
                );
                const pending = allTasks.filter(task => 
                    task.status === 'pending'
                );

                setTasks(allTasks);
                setTimelyTasks(timely);
                setLateTasks(late);
                setPendingTasks(pending);
            } catch (error) {
                console.error("Error fetching tasks:", error);
            }
        };

        fetchTasks();
    }, []);

    return (
        <div className="overdue-events">
            <h3 className="overdue-title">Compliances</h3>

            <div className="task-section">
                <h4 className='timely'>Timely Submitted Compliance</h4>
                <ul className="event-list">
                    {timelyTasks.map(task => (
                        <li key={task._id} className="event-item timely">
                            {task.title}
                        </li>
                    ))}
                </ul>
            </div>

            <div className="task-section">
                <h4 className='late'>Late Submitted Compliance</h4>
                <ul className="event-list">
                    {lateTasks.map(task => (
                        <li key={task._id} className="event-item late">
                            {task.title}
                        </li>
                    ))}
                </ul>
            </div>

            {/* New Pending Tasks Section */}
            <div className="task-section">
                <h4 className='pending'>Pending Compliance</h4>
                <ul className="event-list">
                    {pendingTasks.map(task => (
                        <li key={task._id} className="event-item pending">
                            {task.title}
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default OverdueEvents;
