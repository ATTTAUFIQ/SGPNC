import React from 'react';
import './UserManual.css'; // Optional: Add custom styling in this file
import { useAuth } from './Context/auth'; // Assuming you have an auth context to determine user roles

const UserManual = () => {
    const { auth } = useAuth();
    const userRole = auth?.role;

    return (
        <div className="user-manual">
            <h1>User Manual</h1>
            <section>
                <h2>Introduction</h2>
                <p>
                    Welcome to the Calendar Application! This guide will help you navigate through the features, including
                    viewing events, managing compliances, and navigating the calendar effectively.
                </p>
            </section>

            {/* General Instructions */}
            <section>
                <h2>Getting Started</h2>
                <p>
                    After logging in, you will see the main dashboard displaying an interactive calendar view. You can navigate between months
                    and view events scheduled for each date.
                </p>
            </section>

            {/* Employee Instructions */}
            {userRole === 'employee' && (
                <section>
                    <h2>Employee Guide</h2>
                    <ul>
                        <li><strong>Viewing Compliance:</strong> Dates with compliances assigned to you are highlighted on the calendar.</li>
                        <li><strong>Compliance Status:</strong> Hover over a compliance date to see its name and current status, such as "Pending" or "Completed".</li>
                        <li><strong>Compliance Details:</strong> Click on a compliance to view more details or update its progress, if applicable.</li>
                    </ul>
                </section>
            )}

            {/* Admin Instructions */}
            {userRole === 'admin' && (
                <section>
                    <h2>Admin Guide</h2>
                    <ul>
                        <li><strong>Managing compliances:</strong> Use the "Admin" section in the navigation bar to view and manage all compliances. You can add, edit, or delete compliances as needed.</li>
                        <li><strong>Assigning compliances:</strong> Assign compliances to specific employees and set due dates, which will be highlighted on the employee's calendar view.</li>
                        <li><strong>Event Overview:</strong> Access an overview of all events and their statuses, including pending, completed, and overdue compliances.</li>
                        <li><strong>Reports:</strong> Generate reports on compliance completions and overdue events, helping track team productivity.</li>
                    </ul>
                </section>
            )}

            {/* Shared Instructions */}
            <section>
                <h2>General Calendar Navigation</h2>
                <ul>
                    <li><strong>Navigate Months:</strong> Use the arrows at the top of the calendar to switch between months.</li>
                    <li><strong>Today’s Date:</strong> The current date is highlighted on the calendar for quick reference.</li>
                    <li><strong>Viewing compliance Details:</strong> Hover over any highlighted date to view compliance names and their statuses.</li>
                </ul>
            </section>

            <section>
                <h2>Troubleshooting & Support</h2>
                <p>If you experience any issues:</p>
                <ul>
                    <li><strong>Check Connection:</strong> Make sure you're connected to the internet.</li>
                    <li><strong>Refresh Page:</strong> Reload the page if events aren't displaying correctly.</li>
                    <li><strong>Contact Support:</strong> For further assistance, contact support at [support@example.com] or call [phone number].</li>
                </ul>
            </section>
        </div>
    );
};

export default UserManual;
