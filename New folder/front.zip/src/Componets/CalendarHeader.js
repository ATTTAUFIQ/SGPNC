// CalendarHeader.js
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Import useNavigate
import './CalendarHeader.css';
import { useAuth } from './Context/auth';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';

const CalendarHeader = () => {
    const { auth, logout } = useAuth();
    const [showLogout, setShowLogout] = useState(false);
    const navigate = useNavigate(); // Initialize navigate

    // Handle logout and navigate to the home page
    const handleLogout = () => {
        logout(); // Perform logout logic
        navigate('/'); // Redirect to the home page
    };

    return (
        <div className="calendar-header">
            <Link to="/main" className="log">
            <img src='SGPNC_Logo_FINAL_page-small.jpg' alt="SGPNC Logo" />
            </Link>


            <nav className="nav-links">
                <Link to="/main">Dashboard</Link>
                {/* Conditionally render "Events" link for employees */}
                {auth?.role === 'employee' && (
                    <Link to="/events">Events</Link>
                )}
                {/* <Link to="/about">About</Link> */}
                <Link to="/usermanual">User Manual</Link>
                {/* Conditionally render "Admin" link for admins and super admins */}
                {(auth?.role === 'admin') && (
                    <Link to="/admin">Admin</Link>
                )}
                {(auth?.role === 'superAdmin') && (
                    <Link to="/superAdmin">Super Admin</Link>
                )}
                <span
                    className="user-icon"
                    onMouseEnter={() => setShowLogout(true)}
                    onMouseLeave={() => setShowLogout(false)}
                    style={{ margin: '0 10px' }} // Add margin here
                >
                    <FontAwesomeIcon 
                        icon={faUser} 
                        style={{ 
                            color: 'white', 
                            height: '20px',
                            width: '20px',
                            marginRight: '8px'
                        }} 
                    />
                    <span className="user-name">{auth?.user || "Guest"}</span>
                    {auth.token ? (
                        showLogout && (
                            <button className="logout-button" onClick={handleLogout}>
                                Logout
                            </button>
                        )
                    ) : (
                        <Link to="/" className="login-button">Login</Link>
                    )}
                </span>
            </nav>
        </div>
    );
};

export default CalendarHeader;
