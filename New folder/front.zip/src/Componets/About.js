import React from 'react';
import './About.css';

const About = () => {
    return (
        <div className="about-page">
            <h1>About Us</h1>
            <section className="company-info">
                <h2>Shree Ganesh Press N Coat Ind Pvt. Ltd.</h2>
                <p>
                    Established in 2000, Shree Ganesh Press-N-Coat Industries Pvt. Ltd. is engaged in manufacturing, wholesale trading, 
                    and exporting of Toggle Clamp, Eco Pellet Maker Machine, and more. Under the supervision of Sachin Khesar, we have achieved great heights.
                </p>
                
                <h3>Factsheet</h3>
                <ul>
                    <li>Year of Establishment: 2000</li>
                    <li>Company Type: Private Limited</li>
                    <li>Key Products: Toggle Clamp, Eco Pellet Maker Machine</li>
                    <li>Headed By: Sachin Khesar</li>
                </ul>
                
                <h3>Reach Us</h3>
                <div className="reach-info">
                    <p>Shree Ganesh Press N Coat Ind Pvt. Ltd.</p>
                    <p>Plot M-152, MIDC Waluj MIDC, Zambad Chowk, Aurangabad-431136, Maharashtra, India</p>
                    <a href="https://www.google.com/maps" target="_blank" rel="noopener noreferrer">Get Directions</a>
                    <p>Nilesh Kulkarni (Development Engineer)</p>
                    <p>Call Response Rate: 93%</p>
                    <div className="contact-actions">
                        <button>View Mobile Number</button>
                        <button>Send SMS</button>
                        <button>Send Email</button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default About;
