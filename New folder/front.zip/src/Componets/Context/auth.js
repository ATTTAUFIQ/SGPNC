// AuthContext.js
import { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";

const AuthContext = createContext();

// AuthProvider Component
export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState({
    user: null,
    token: "",
    role:"",
    departmentId:"",
  });

  useEffect(() => {
    const savedAuth = localStorage.getItem("auth");
    if (savedAuth) {
      const parsedAuth = JSON.parse(savedAuth);
      setAuth(parsedAuth);

      // Set token in Axios headers for all requests
      axios.defaults.headers.common["Authorization"] = `Bearer ${parsedAuth.token}`;
    }
  }, []);

  const login = (user, token,role,departmentId) => {
    setAuth({ user, token ,role,departmentId});
    localStorage.setItem("auth", JSON.stringify({ user, token, role ,departmentId}));
    axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  };

  const logout = () => {
    setAuth({ user: null, token: "" ,role:"",departmentId:""});
    localStorage.removeItem("auth");
    delete axios.defaults.headers.common["Authorization"];
  };

  return (
    <AuthContext.Provider value={{ auth, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook for easier access
export const useAuth = () => useContext(AuthContext);
