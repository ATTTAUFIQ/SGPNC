import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./App.css";
import CalendarHeader from "./Componets/CalendarHeader"; // Fixed path
import MainComponent from "./Componets/MainComponent"; // Fixed path
import AdminLayout from "./Componets/Admin/AdminLayout"; // Fixed path
import AddTask from "./Componets/Admin/AddTask"; // Fixed path
import EditTask from "./Componets/Admin/EditTask"; // Fixed path
import CompletedTask from "./Componets/Admin/CompletedTask"; // Fixed path
import DelayedTask from "./Componets/Admin/DelayedTask"; // Fixed path
import Register from "./Componets/Register"; // Fixed path
import LoginPage from "./Componets/Login";
import { AuthProvider } from "./Componets/Context/auth";
import DisplayComponent from "./Componets/Admin/DisplayComponet";
import Events from "./Componets/User/Events";
import UserManual from "./Componets/UserManual";
import About from "./Componets/About";
import SuperTask from "./Componets/Admin/SuperTask";
import SuperAdminLayout from "./Componets/Admin/SuperAdminLayout";
import SuperUsers from "./Componets/Admin/SuperUsers";
import SuperDeperment from "./Componets/Admin/SuperDeperment";
import SuperCreateDperment from "./Componets/Admin/SuperCreateDperment";
import Forgot from "./Componets/Forgot";

function App() {
  const [tasks, setTasks] = useState([]);

  const handleAddTask = (task) => {
    if (task && task.taskName && task.assignedTo && task.dueDate) {
      setTasks([...tasks, task]);
    } else {
      console.error("Invalid task data:", task);
    }
  };

  return (
    <AuthProvider>
      <Router>
        <CalendarHeader tasks={tasks} />
        <Routes>
          {/* Main routes */}
          <Route path="/" element={<LoginPage />} />
          <Route path="/register" element={<Register />} />

          <Route path="/main" element={<MainComponent tasks={tasks} />} />

          <Route path="/events" element={<Events />} />

          <Route path="/usermanual" element={<UserManual />} />

          <Route path="/about" element={<About />} />

          <Route path="/forget" element={<Forgot />} />

          <Route path="/superAdmin" element={<SuperAdminLayout />}>
            <Route path="" element={<SuperCreateDperment/>}></Route>
            <Route path="superUser" element={<SuperUsers />}></Route>
            <Route path="superTask" element={<SuperTask />} />
            <Route path="superDept" element={<SuperDeperment />} />
          </Route>

          {/* Admin routes wrapped in AdminLayout */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route path="" element={<AddTask onAddTask={handleAddTask} />} />
            <Route path="edit-task/:id" element={<EditTask />} />
            <Route path="display-task" element={<DisplayComponent />} />
            <Route path="completed-task" element={<CompletedTask />} />
            <Route path="delayed-task" element={<DelayedTask />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
