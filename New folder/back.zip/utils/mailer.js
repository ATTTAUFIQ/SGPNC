const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  host: 'smtp.zoho.com', // Zoho SMTP host
  port: 465, // Secure port for Zoho (SSL)
  secure: true, // Use SSL
  auth: {
    user: process.env.EMAIL_USER, // Your Zoho email address
    pass: process.env.EMAIL_PASS, // Your Zoho email password or App Password
  },
});

// Function to send reminder emails
const sendReminderEmail = async (to, subject, htmlContent) => {
  const mailOptions = {
    from: `"Compliance Reminder" <${process.env.EMAIL_USER}>`, // Sender's email address
    to, // Recipient's email address
    subject, // Email subject
    html: htmlContent, // Email body in HTML format
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Email sent to ${to}`);
  } catch (error) {
    console.error('Error sending email:', error);
  }
};

module.exports = { sendReminderEmail };
