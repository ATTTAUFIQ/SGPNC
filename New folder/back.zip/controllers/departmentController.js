// controllers/departmentController.js
const Department = require('../models/Department');

exports.createDepartment = async (req, res) => {
  const { name, adminId } = req.body;
  try {
    const department = new Department({ name, adminId });
    await department.save();
    res.status(201).json({ message: 'Department created successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.getDepartments = async (req, res) => {
  try {
    const departments = await Department.find();
    res.json(departments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
