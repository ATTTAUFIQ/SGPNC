const User = require('../models/User');
const generateToken = require('../utils/generateToken'); // Assume this generates JWT tokens
const bcrypt = require('bcrypt');

exports.registerUser = async (req, res) => {
  const { name, email, password, role, departmentId ,DOB} = req.body;
  try {
    const user = new User({ name, email, password, role, departmentId,DOB });
    await user.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.loginUser = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      departmentId:user.departmentId,
      token: generateToken(user._id), // Generate a token for the user
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


exports.registerBulkUsers = async (req, res) => {
  const usersData = req.body; // Expecting an array of user objects
  try {
    // Hash each user's password
    const usersWithHashedPasswords = await Promise.all(usersData.map(async (user) => {
      const hashedPassword = await bcrypt.hash(user.password, 10);
      return {
        ...user,
        password: hashedPassword,
      };
    }));

    const users = await User.insertMany(usersWithHashedPasswords);
    res.status(201).json({ message: `${users.length} users registered successfully` });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.updatePassword = async (req, res) => {
  const { email, DOB, password } = req.body;

  // Validate input
  if (!email || !DOB || !password) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    // Find the user by email
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // Format both DOB values to YYYY-MM-DD for comparison
    const inputDOB = new Date(DOB).toISOString().split('T')[0]; // Convert input DOB
    const storedDOB = new Date(user.DOB).toISOString().split('T')[0]; // Convert stored DOB

    // Check if the provided DOB matches the stored DOB
    if (inputDOB !== storedDOB) {
      return res.status(400).json({ message: 'Date of Birth does not match our records.' });
    }
    user.password = password;
    await user.save();

    res.status(200).json({ message: 'Password updated successfully.' });
  } catch (error) {
    console.error('Error in forgot-password:', error);
    res.status(500).json({ message: 'An error occurred. Please try again later.' });
  }
};

exports.deleteUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify the provided password
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Incorrect password' });
    }

    // Delete the user
    await User.findOneAndDelete({ email });
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


exports.updateRole = async (req, res) => {
    const { role } = req.body; // The new role passed in the request body
    const uid = req.params.userId; // User ID passed as a URL parameter

    try {
        // Find the user by ID and update the role
        const updatedUser = await User.findOneAndUpdate(
            { _id: uid }, // Match user by ID
            { role }, // Update the role field
            { new: true } // Return the updated document
        );

        // If no user is found, return 404
        if (!updatedUser) {
            return res.status(404).json({ message: 'No user found with this ID' });
        }

        // Respond with success message and updated user details
        res.status(200).json({
            message: 'Role updated successfully',
            user: updatedUser, // Return updated user details for confirmation
        });
    } catch (error) {
        console.error('Error updating role:', error); // Log error for debugging
        res.status(400).json({ message: 'An error occurred while updating the role' });
    }
};
