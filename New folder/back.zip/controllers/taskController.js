
// controllers/taskController.js
const Task = require('../models/Task');

exports.createTask = async (req, res) => {
  const { title, description, assignedTo, status, departmentId, startDate, endDate, dueDate } = req.body;
  try {
    const task = new Task({
      title,
      description,
      assignedTo,
      departmentId,
      status,
      assignedBy: req.user._id,
      startDate,
      endDate,
      dueDate,
    });
    await task.save();
    res.status(201).json({ message: 'Task created successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.getupAdmin=async(req, res)=>{
  try {
    const id=req.params.id
    const tasks = await Task.findById(id);
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

exports.getTasks = async (req, res) => {
  try {
    const tasks = await Task.find({ assignedTo: req.user._id });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateTaskStatus = async (req, res) => {
  try {
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, assignedTo: req.user._id },
      { status: req.body.status },
      { new: true }
    );
    res.json(task);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};



exports.getDepartmentTasks = async (req, res) => {
  try {
      const departmentId = req.user.departmentId; // Assuming the user object contains department info
      const tasks = await Task.find({ departmentId: departmentId }); // Adjust according to your Task schema
      res.status(200).json(tasks);
  } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
  }
};
exports.getAllTasks = async (req, res) => {
  try {
      const tasks = await Task.find(); // Fetch all tasks from the database
      res.status(200).json(tasks);
  } catch (error) {
      console.error('Error fetching all tasks:', error);
      res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// New function for updating tasks by Department Admin
exports.updateDepartmentTask = async (req, res) => {
  const { title, description, status, startDate, endDate, dueDate } = req.body;
  try {
      const taskId = req.params.id;

      const updatedTask = await Task.findOneAndUpdate(
          { _id: taskId, departmentId: req.user.departmentId },
          { title, description, status, startDate, endDate, dueDate },
          { new: true, runValidators: true }
      );

      if (!updatedTask) {
          return res.status(404).json({ message: 'Task not found or not in your department' });
      }

      res.status(200).json(updatedTask);
  } catch (error) {
      res.status(400).json({ message: error.message });
  }
};

exports.deleteTask= async (req, res) => {
  try {
      const taskId = req.params.id;
      // Find and delete the task if it belongs to the department
      const deletedTask = await Task.findOneAndDelete({_id: taskId});

      if (!deletedTask) {
          return res.status(404).json({ message: 'Task not found or not in your department' });
      }

      res.status(200).json({ message: 'Task deleted successfully' });
  } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Bulk tasks addition
exports.registerBulkTasks = async (req, res) => {
  const { tasks } = req.body; // Expecting an object with a tasks array
  try {
    console.log("Request body:", req.body); // Debug incoming request
    if (!Array.isArray(tasks) || tasks.length === 0) {
      console.log("Invalid tasks array:", tasks); // Debug invalid input
      return res.status(400).json({ message: 'No tasks provided or invalid format' });
    }

    // Validate individual tasks
    const tasksToInsert = tasks.map((task) => {
      if (
        !task.title ||
        !task.description ||
        !task.assignedTo ||
        !task.departmentId ||
        !task.assignedBy ||
        !task.startDate ||
        !task.endDate ||
        !task.dueDate
      ) {
        throw new Error(`Missing required fields in task: ${JSON.stringify(task)}`);
      }

      return {
        title: task.title,
        description: task.description,
        assignedTo: task.assignedTo,
        departmentId: task.departmentId,
        assignedBy: task.assignedBy,
        startDate: new Date(task.startDate),
        endDate: new Date(task.endDate),
        dueDate: new Date(task.dueDate),
        status: task.status || 'pending',
      };
    });

    // Insert tasks into the database
    const insertedTasks = await Task.insertMany(tasksToInsert);

    res.status(201).json(`{message: ${insertedTasks.length} tasks created successfully }`);
  } catch (error) {
    console.error('Error in bulk task registration:', error.message);
    res.status(400).json({ message: error.message });
  }
};