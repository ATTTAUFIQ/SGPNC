const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const userRoutes = require('./routes/userRoutes');
const departmentRoutes = require('./routes/departmentRoutes');
const taskRoutes = require('./routes/taskRoutes');
const { errorHandler } = require('./middleware/errorHandler');
const cron = require('node-cron');
const { sendReminderEmail } = require('./utils/mailer'); // Import your mailer
const Task = require('./models/Task'); // Import your Task model

dotenv.config();
connectDB();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Routes
app.use('/api/users', userRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/tasks', taskRoutes);

app.get('/', (req, res) => {
  res.send('Compliance Calendar API is running...');
});

// Scheduled job to send reminder emails daily at 12:30 PM
cron.schedule('30 12 * * *', async () => {
  try {
      const upcomingTasks = await Task.find({
    dueDate: { $gte: new Date(), $lt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) }, // Next 7 days
      status: 'pending', // Only select tasks with status "pending"
    }).populate('assignedTo'); // Populate the assigned user to get email
    

    if (upcomingTasks.length === 0) {
      console.log('No upcoming tasks found.');
      return;
    }

    for (const task of upcomingTasks) {
      const userEmail = task.assignedTo.email; // Make sure your User model has an email field
      const { title, startDate, dueDate, endDate } = task;

      const emailSubject = `Reminder: Upcoming Task - ${title}`;
      const emailBody = `
        <h3>Task Reminder</h3>
        <p>Dear User,</p>
        <p>This is a friendly reminder about your upcoming task:</p>
        <h4>Task Title: ${title}</h4>
        <p><strong>Start Date:</strong> ${startDate}</p>
        <p><strong>Due Date:</strong> ${dueDate}</p>
        <p><strong>Last Submission Date:</strong> ${endDate}</p>
        <p>Don't forget to complete your task on time!</p>
        <p>Best regards,<br>Your Task Management Team</p>
      `;

      await sendReminderEmail(userEmail, emailSubject, emailBody);
    }
  } catch (error) {
    console.error('Error in scheduled email sending:', error);
  }
});


// Error Handling Middleware
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
