// routes/taskRoutes.js
const express = require('express');
const { createTask, getTasks, updateTaskStatus,getDepartmentTasks,getAllTasks,getupAdmin ,updateDepartmentTask,deleteTask,registerBulkTasks} = require('../controllers/taskController');
const { isDepartmentAdmin, isEmployee, protect,isSuperAdmin } = require('../middleware/auth');
const router = express.Router();



// Correctly set up the route for fetching department tasks

//SuperADMIN

//1. READ ==== Super route Admin tasks to get all tasks
router.get('/all', protect, isSuperAdmin, getAllTasks);

//DepartmentADMIN

//1. CREATE ==== Create route tasks for department admin 
router.post('/',protect ,isDepartmentAdmin, createTask);

//2. READ  ==== Admin route  task to get all the tasks acccording to the department
router.get('/department', protect, isDepartmentAdmin, getDepartmentTasks);

// 3. delete ===
router.delete('/department/:id', protect, isDepartmentAdmin, deleteTask);

// 4. UPDATE ==== Department admin route to update a task in their department
router.patch('/department/:id', protect, isDepartmentAdmin, updateDepartmentTask);

router.get('/:id',protect ,isDepartmentAdmin, getupAdmin); // update data

router.post('/register/bulk/tasks', registerBulkTasks);







//EMPLOYEEE

//1.READ ==== Employye route to get the tasks assigned
router.get('/',protect, isEmployee, getTasks);

//2.UPDATE ==== employee route to update status of tasks
router.patch('/:id',protect, isEmployee, updateTaskStatus);

module.exports = router;