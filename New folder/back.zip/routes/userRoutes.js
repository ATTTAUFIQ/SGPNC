const express = require('express');
const { registerUser, loginUser, getUsers, registerBulkUsers, updatePassword, deleteUser,updateRole} = require('../controllers/userController');
const router = express.Router();

// User Registration
router.post('/register', registerUser);

// User Login
router.post('/login', loginUser);

// update role
router.put('/role/:userId', updateRole);


// Update Password
router.post('/update-password', updatePassword); // New route

// Get Users (optional, for admin)
router.get('/', getUsers);


// Delete User
router.delete('/delete', deleteUser); // New route


router.post('/register/bulk', registerBulkUsers);



module.exports = router;
