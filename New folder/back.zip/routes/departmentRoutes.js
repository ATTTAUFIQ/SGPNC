// routes/departmentRoutes.js
const express = require('express');
const { createDepartment, getDepartments } = require('../controllers/departmentController');
const { protect, isDepartmentAdmin} = require('../middleware/auth');
const router = express.Router();

router.post('/', protect, createDepartment);
router.get('/', getDepartments);

module.exports = router;
